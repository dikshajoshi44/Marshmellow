package com.marshmallow.hiring.service;

import com.marshmallow.hiring.enums.Direction;
import com.marshmallow.hiring.exceptions.NavigationFailureException;
import lombok.Data;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
public class Grid {

    private Integer width;
    private Integer height;
    private Set<String> oilPatchesTobeCleaned;

    public Grid(List<Integer> areaSize, List<List<Integer>> oilPatches) {
        this.width = areaSize.get(0);
        this.height = areaSize.get(1);
        this.oilPatchesTobeCleaned = oilPatches.stream()
                .map(patch-> patch.get(0) + "," + patch.get(1))
                .collect(Collectors.toSet());
    }


    public List<Integer> moveRobot(List<Integer> startingPosition, String navigationInstructions) {

        Integer cleanedNoOfPatches = 0;
        Integer currentXCoordinate = startingPosition.get(0);
        Integer currentYCoordinate = startingPosition.get(1);

        validateBoundCheck(currentXCoordinate, currentYCoordinate);
        cleanedNoOfPatches = calculateCleanOilPatches(currentXCoordinate, currentYCoordinate, cleanedNoOfPatches);

        for(char currChar : navigationInstructions.toCharArray()) {
            Integer nextXCoordinate = currentXCoordinate + Direction.getDirectionFromChar(currChar).getDelataX();
            Integer nextYCoordinate = currentYCoordinate + Direction.getDirectionFromChar(currChar).getDelataY();

            if(validateBoundCheck(nextXCoordinate, nextYCoordinate)){
                currentXCoordinate = nextXCoordinate;
                currentYCoordinate =  nextYCoordinate;
                cleanedNoOfPatches = calculateCleanOilPatches(currentXCoordinate, currentYCoordinate, cleanedNoOfPatches);

            }

        }

        return List.of(currentXCoordinate, currentYCoordinate, cleanedNoOfPatches);

    }

    private Boolean validateBoundCheck(Integer nextXCoordinate, Integer nextYCoordinate) {

        if(nextXCoordinate >= 0 && nextXCoordinate < width && nextYCoordinate >= 0 && nextYCoordinate < height){
            return true;
        }else {
            throw new NavigationFailureException("validateBoundCheck failed for new co ordinates");
        }

    }

    public Integer calculateCleanOilPatches(Integer currentXCoordinate, Integer currentYCoordinate,
                                            Integer cleanedNoOfPatches ) {
        String oilSpilledString =  currentXCoordinate + "," + currentYCoordinate;
        if(oilPatchesTobeCleaned.contains(oilSpilledString)){
            cleanedNoOfPatches++;
            oilPatchesTobeCleaned.remove(oilSpilledString);
        }

        return cleanedNoOfPatches;
    }
}
