package com.marshmallow.hiring.exceptions;

public class NavigationFailureException extends RuntimeException{

    public NavigationFailureException(String message) {
        super(message);
    }
}
