package com.marshmallow.hiring.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(value= {NavigationFailureException.class, IllegalArgumentException.class, RuntimeException.class})
    public ResponseEntity<?> handleNavigationFailureException(NavigationFailureException ex) {
        NavigationException navigationException = new NavigationException(ex.getMessage(), HttpStatus.BAD_REQUEST, ex.getCause());
        return new ResponseEntity<>(navigationException, HttpStatus.BAD_REQUEST);
    }
}
