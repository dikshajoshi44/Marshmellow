package com.marshmallow.hiring.validators;

import com.marshmallow.hiring.exceptions.NavigationFailureException;

import java.util.List;
import java.util.Objects;

public class ValidateNavigationInput {

    public void validateInput(final List<Integer> startingPosition,
                              final String navigationInstructions,
                              final List<Integer> areaSize,
                              final List<List<Integer>> oilPatches) {

        if(Objects.isNull(startingPosition) || Objects.isNull(navigationInstructions) || Objects.isNull(areaSize)
                ||Objects.isNull(oilPatches)) {
            throw new NavigationFailureException("Input values are Null or Empty");
        }

        if(startingPosition.size() != 2 || areaSize.size() != 2) {
            throw new NavigationFailureException("Input values are incorrect");
        }

        for(Integer pos: startingPosition) {
            if(pos < 0) {
                throw new NavigationFailureException("StartingPosition value is out of Bounds");
            }
        }

        for(Integer pos: areaSize) {
            if(pos <= 0) {
                throw new NavigationFailureException("AreaSize value is out of Bounds");
            }
        }

        for(List<Integer> pos: oilPatches) {
            if((pos.get(0) < 0) || (pos.get(1) < 0)) {
                throw new NavigationFailureException("Input values are Null or Empty");
            }
        }

    }


}
