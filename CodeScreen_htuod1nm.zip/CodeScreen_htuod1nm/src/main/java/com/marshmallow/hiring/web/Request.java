package com.marshmallow.hiring.web;

import java.util.List;

// do not modify this file for the purposes of the exercise
public record Request(List<Integer> areaSize,
                      List<Integer> startingPosition,
                      List<List<Integer>> oilPatches,
                      String navigationInstructions
) {
}
