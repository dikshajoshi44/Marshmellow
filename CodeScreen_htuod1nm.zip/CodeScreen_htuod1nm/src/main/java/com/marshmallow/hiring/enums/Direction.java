package com.marshmallow.hiring.enums;

import com.marshmallow.hiring.exceptions.NavigationFailureException;
import lombok.Getter;

@Getter
public enum Direction {

    NORTH(0, 1),
    SOUTH(0, -1),
    EAST(1, 0),
    WEST(-1, 0);

    private Integer delataX;
    private Integer delataY;

    Direction(Integer delataX, Integer delataY) {
        this.delataX = delataX;
        this.delataY = delataY;
    }


    public static Direction getDirectionFromChar(char directionChar) {
        switch(Character.toUpperCase(directionChar)){
            case 'N':
                return NORTH;
            case 'S':
                return SOUTH;
            case 'E':
                return EAST;
            case 'W':
                return WEST;
            default:
                throw new NavigationFailureException("Wrong Nagivation Input given");

        }
    }


}
