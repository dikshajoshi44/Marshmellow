package com.marshmallow.hiring.service;

import com.marshmallow.hiring.web.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class Service {

    // do not modify this method signature for the purposes of the exercise
    public Response navigate(final List<Integer> startingPosition,
                             final String navigationInstructions,
                             final List<Integer> areaSize,
                             final List<List<Integer>> oilPatches) {
        // TODO implement requirements here
        //  validateNavigationInput.validateInput(startingPosition, navigationInstructions, areaSize, oilPatches);
        Grid grid = new Grid(areaSize, oilPatches);
        List<Integer> results = grid.moveRobot(startingPosition, navigationInstructions);
        return new Response(List.of(results.get(0), results.get(1)), results.get(2));
    }

}
