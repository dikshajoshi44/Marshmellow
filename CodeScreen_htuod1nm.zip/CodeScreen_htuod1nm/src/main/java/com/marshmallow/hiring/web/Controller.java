package com.marshmallow.hiring.web;

import com.marshmallow.hiring.service.Service;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    private static final Logger log = org.slf4j.LoggerFactory.getLogger(Controller.class);

    private final Service service;

    public Controller(final Service service) {
        this.service = service;
    }

//    @ExceptionHandler(RuntimeException.class)
//    public ResponseEntity<Void> handle(final RuntimeException ex) {
//        log.error("Unexpected exception while handling request", ex);
//        return ResponseEntity
//            .internalServerError()
//            .build();
//    }

    @PostMapping("/instructions")
    public ResponseEntity<Response> instructions(final @Valid @RequestBody Request request) {
        // do not modify this method for the purposes of the exercise
        log.info(request.toString());

        final Response response = service.navigate(
            request.startingPosition(),
            request.navigationInstructions(),
            request.areaSize(),
            request.oilPatches()
        );

        log.info(response.toString());
        return ResponseEntity.ok(response);
    }

}
