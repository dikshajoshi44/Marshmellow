package com.marshmallow.hiring.exceptions;

import lombok.Data;
import org.springframework.http.HttpStatus;

@Data
public class NavigationException {
    private String errorMessage;
    private HttpStatus status;
    private Throwable cause;

    public NavigationException(String errorMessage, HttpStatus status, Throwable cause) {
        this.errorMessage = errorMessage;
        this.status = status;
        this.cause = cause;
    }
}
