package com.marshmallow.hiring;

import com.marshmallow.hiring.web.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.MethodOrderer.MethodName;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.OK;

@TestMethodOrder(MethodName.class)
@SpringBootTest(webEnvironment = RANDOM_PORT)
class MarshmallowEndToEndTests {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    static Stream<Arguments> section1_robotAcceptsInstructionsAndNavigatesToCorrectPosition() {
        return Stream.of(
            arguments("N", List.of(2, 3)),
            arguments("E", List.of(3, 2)),
            arguments("S", List.of(2, 1)),
            arguments("W", List.of(1, 2)),
            arguments("NE", List.of(3, 3)),
            arguments("SW", List.of(1, 1))
        );
    }

    @MethodSource
    @ParameterizedTest
    void section1_robotAcceptsInstructionsAndNavigatesToCorrectPosition(final String navigationInstructions,
                                                                        final List<Integer> expectedFinalPosition) {
        //language=JSON
        final String requestJson = """
            {
              "areaSize": [5, 5],
              "startingPosition" : [2, 2],
              "navigationInstructions" : "%s",
              "oilPatches": []
            }
            """.formatted(navigationInstructions);

        final ResponseEntity<Response> responseEntity = postInstructions(requestJson);

        assertThat(responseEntity.getStatusCode()).isEqualTo(OK);

        final Response response = responseEntity.getBody();
        assertThat(response).isNotNull();
        assertThat(response.finalPosition()).isEqualTo(expectedFinalPosition);
    }

    @ParameterizedTest
    @ValueSource(strings = {
        "N",
        "S",
        "E",
        "W"
    })
    void section2_robotIsLimitedTo1x1Grid_returnsBadRequestWhenRobotMoves(final String navigationInstructions) {
        //language=JSON
        final String requestJson = """
            {
              "areaSize": [1, 1],
              "startingPosition": [0, 0],
              "navigationInstructions": "%s",
              "oilPatches": []
            }
            """.formatted(navigationInstructions);

        final ResponseEntity<Response> responseEntity = postInstructions(requestJson);

        assertThat(responseEntity.getStatusCode()).isEqualTo(BAD_REQUEST);
    }

    @Test
    void section3_robotCanCleanOilSpills() {
        //language=JSON
        final String requestJson = """
            {
              "areaSize": [5, 5],
              "startingPosition": [2, 2],
              "navigationInstructions": "NWEEWN",
              "oilPatches": [
                [2, 1],
                [2, 2],
                [2, 3],
                [2, 4]
              ]
            }
            """;

        final ResponseEntity<Response> responseEntity = postInstructions(requestJson);

        assertThat(responseEntity.getStatusCode()).isEqualTo(OK);

        final Response response = responseEntity.getBody();
        assertThat(response).isNotNull();
        assertThat(response.finalPosition()).isEqualTo(List.of(2, 4));
        assertThat(response.oilPatchesCleaned()).isEqualTo(3);
    }

    private ResponseEntity<Response> postInstructions(final String instructions) {
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        return restTemplate.postForEntity(requestUrl(), new HttpEntity<>(instructions, headers), Response.class);
    }

    private String requestUrl() {
        return "http://localhost:%s/instructions".formatted(port);
    }

}
