<h1 align="center">
  <br>
  <img src="https://global-uploads.webflow.com/5baa461315ee32413d16236d/5bb3a6170a88c4f84b60dc67_mallows.svg" alt="Marshmallow" width="200">
  <br>
  Marshmallow Engineering Live Pairing Exercise
  <br>
</h1>

## Setup

* ☕️ Please make sure you have Java 17 installed on your local machine and configured in your IDE in order to
  successfully compile this project and run the tests.
    * ⚠️ *Please note that the tests will fail and this is expected. Our goal in the exercise will be to get the tests
      to succeed.*
* 🎁 The project includes a Maven wrapper, so you do not need to install Maven locally.
    * 🐧 Use `./mvnw clean test` on a Unix system
    * 🪟 Use `./mvnw.cmd clean test` for Batch
* ⚠️ We are providing [Lombok](https://projectlombok.org) in the project classpath if you are familiar with using it.
  Make sure to enable annotation processing in your IDE for the project if you wish to use it.

## Task

You will be paired with one or more Marshmallow engineers, and we will go through the requirements incrementally,
continuously building our solution to reach the final finished product. Please do not hesitate to ask clarifying
questions at any point in the process, and we encourage you to speak your thoughts out loud as we go through the
exercise.

Your task is to write a Java based web service that navigates an imaginary robotic cleaner through an oil spill in the
sea. The first step of the task is explained below to give you time to get to know the problem and start thinking about
your approach towards a solution.

<hr />

The following request contains information for a robot's position in a 2D grid space using Cartesian coordinates. The
first step of the task is to make the robot follow the given navigation instructions and return the final position of
the robot. A visual aid is provided below for reference.

Some code has also been provided to help get you started, this includes:

- A `Request` record that matches the expected request JSON.
- A `Response` record that matches the expected response JSON.
- A `Service` class that is a Spring `@Component` which contains a navigate method.
- A `Controller` class that is a Spring `@RestController`.
    - The class already contains a `@PostMapping` endpoint that accepts a `Request` object, calls
      the `Service#navigate()` method and returns the `Response` object with a `200` responses.
    - The class also includes a Spring `@ExceptionHandler` that handles any exception to return a `500` response.

**For the purposes of the exercise, please focus on the logical implementation of the `Service#navigate()` method. Feel
free to create and use any additional supporting methods or classes as you see fit.**

```json
{
  "startingPosition": [
    1,
    2
  ],
  "navigationInstructions": "EEN",
  "areaSize": [
    5,
    5
  ],
  "oilPatches": []
}
```

![Visual Aid](visual_aid.png)
## License

At CodeScreen, we strongly value the integrity and privacy of our assessments. As a result, this repository is under exclusive copyright, which means you **do not** have permission to share your solution to this test publicly (i.e., inside a public GitHub/GitLab repo, on Reddit, etc.). <br>

## Submitting your solution

Please push your changes to the `main branch` of this repository. You can push one or more commits. <br>

Once you are finished with the task, please click the `Submit Solution` link on <a href="https://app.codescreen.com/candidate/6af1a67a-cb72-446c-922c-92dc3b56ea57" target="_blank">this screen</a>.